#pragma once

void pveprn(int**, int**, int, int);

void pvpprn(int**, int**, int, int);

void rprn(int**, int**, int, int);

void prn(int**, int**, int, int);

void lship1(int**, int**, int, int);

void lship2(int**, int**, int, int);

void lship3(int**, int**, int, int);

void lship4(int**, int**, int, int);

void rship1(int**, int**, int, int);

void rship2(int**, int**, int, int);

void rship3(int**, int**, int, int);

void rship4(int**, int**, int, int);


int menu(FILE*, int);

int hit(int** field, FILE*, int);

int wincheck(int**, int, int);

int pvp(int**, int**, int, int, FILE*, int);